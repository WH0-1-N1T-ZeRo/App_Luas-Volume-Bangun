﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Luas_Volume_Bangun
{
    class Rumus
    {
        public int[] ap = new int[5];
        public string[] jl = new string[5];
        public float[] v=new float[5];
        public virtual void mms()
        {
            jl[3] = "P=Panjang\nL=Lebar\nT=Tinggi\nS=Sisi\nR=Jari-jari(D:2)\n\nHarus di ingat";
            jl[4] = "Attention";
        }
    }

}
