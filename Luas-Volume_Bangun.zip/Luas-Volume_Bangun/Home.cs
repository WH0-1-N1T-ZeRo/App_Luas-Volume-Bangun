﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Luas_Volume_Bangun
{

    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            Rumus a = new LV();
            a.mms();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            label5.Text = "";
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }
        } 
//prisma segitiga
//jajargenjang

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.Text)
            {
                case "persegi":
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    label2.Text = "S";
                    label3.Text = "";
                    label4.Text = "";   
                    textBox1.Enabled = true;
                    textBox2.Enabled = false;
                    textBox3.Enabled = false;
                    textBox1.Focus();
                    label5.Text = "";
                   break;
                case "segitiga sama sisi":
                   textBox1.Clear();
                   textBox2.Clear();
                   textBox3.Clear();
                   label2.Text = "A";
                   label3.Text = "T";
                   label4.Text = "";  
                    textBox1.Enabled = true;
                   textBox2.Enabled = true;
                   textBox3.Enabled = false; 
                    textBox1.Focus();  
                    label5.Text = "";
                    break;
                case "lingkaran":
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    label2.Text = "R";
                    label3.Text = "";
                    label4.Text = ""; 
                    textBox1.Enabled = true;
                    textBox2.Enabled = false;
                    textBox3.Enabled = false;
                    textBox1.Focus();
                    label5.Text = "";
                    break;
                case "persegi panjang":
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    label2.Text = "P";  
                    label3.Text = "L"; 
                    label4.Text = "";  
                    textBox1.Enabled = true;
                    textBox2.Enabled = true;
                    textBox3.Enabled = false; 
                    textBox1.Focus(); 
                    label5.Text = "";
                    break;
                case "jajargenjang":
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    label2.Text = "A";
                    label3.Text = "T";
                    label4.Text = ""; 
                    textBox1.Enabled = true;
                    textBox2.Enabled = true;
                    textBox3.Enabled = false; 
                    textBox1.Focus(); 
                    label5.Text = "";
                    break;
                case "balok":
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    label2.Text = "P";
                    label3.Text = "L";
                    label4.Text = "T";  
                    textBox1.Enabled = true;
                    textBox2.Enabled = true;
                    textBox3.Enabled = true;
                    textBox1.Focus(); 
                    label5.Text = "";
                    break;
                case "kubus":
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    label2.Text = "S";
                    label3.Text = "";
                    label4.Text = "";  
                    textBox1.Enabled = true;
                    textBox2.Enabled = false;
                    textBox3.Enabled = false; 
                    textBox1.Focus(); 
                    label5.Text = "";
                    break;
                case "bola":
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    label2.Text = "R";
                    label3.Text = "";
                    label4.Text = "";
                    textBox1.Enabled = true;
                    textBox2.Enabled = false;
                    textBox3.Enabled = false; 
                    textBox1.Focus(); 
                    label5.Text = "";
                    break;
                case "tabung":
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    label2.Text = "A";
                    label3.Text = "T";
                    label4.Text = "";  
                    textBox1.Enabled = true;
                    textBox2.Enabled = true;
                    textBox3.Enabled = false;
                    textBox1.Focus();  
                    label5.Text = "";
                    break;
                case "kerucut":
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    label2.Text = "A";
                    label3.Text = "T";
                    label4.Text = ""; 
                    textBox1.Enabled = true;
                    textBox2.Enabled = true;
                    textBox3.Enabled = false; 
                    textBox1.Focus();  
                    label5.Text = "";
                    break;
                default:
                    textBox2.Enabled = false;
                    textBox3.Enabled = false;
                    textBox1.Enabled = false;
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Rumus a = new Rumus();
            Rumus b = new LV();
            
            switch (comboBox1.Text)
            {
                case "persegi":
                    b.jl[0] = "Luas adalah = S x S \n            = ";
                    b.jl[1] = "Keliling adalah = 4 x S \n               = ";
                    a.ap[0] = int.Parse(textBox1.Text); //s
                    a.ap[3] = a.ap[0] * a.ap[0];
                    a.ap[4] = 4 * a.ap[0];
                    label5.Text = b.jl[0] + a.ap[0] + " x " + a.ap[0] + "\n            = " + a.ap[3].ToString() + "\n" + b.jl[1] + "4 x " + a.ap[0] + "\n               = " + a.ap[4];
                    break;
                case "segitiga sama sisi":
                    b.jl[0] = "Luas adalah = A x T \n            = ";
                    b.jl[1] = "Keliling adalah = 3 x S \n               = ";
                    a.ap[0] = int.Parse(textBox1.Text); //a
                    a.ap[1] = int.Parse(textBox2.Text); //t
                    a.ap[3] = a.ap[0] * a.ap[1]/2;
                    a.ap[4] = 3 * a.ap[0];
                    label5.Text = b.jl[0] + a.ap[0] + " x " + a.ap[1] + " : 2\n            = " + a.ap[3].ToString() + "\n" + b.jl[1] + "3 x " + a.ap[0]+"\n               = " + a.ap[4];
                    break;
                  case "lingkaran":
                      b.jl[0] = "Luas adalah = 2 x 3,14 x r \n            = ";
                      b.jl[1] = "Keliling adalah = 3,14 x r x r \n               = ";
                      a.ap[0] = int.Parse(textBox1.Text); //s
                      a.v[0]=3.14f;
                      a.v[1] = 2*a.v[0]* a.ap[0];
                      a.v[2] = a.v[0] * a.ap[0] * a.ap[0];
                      label5.Text = b.jl[0] + "2 x 3,14 x " + a.ap[0] + "\n            = " + a.v[1].ToString() + "\n" + b.jl[1] + "3,14 x " + a.ap[0] +" x "+ a.ap[0] + ")\n               = " + a.v[2];
                      break;
                   case "persegi panjang":
                       b.jl[0] = "Luas adalah = P x L \n            = ";
                       b.jl[1] = "Keliling adalah = 2 x ( P + L) \n               = ";
                       a.ap[0] = int.Parse(textBox1.Text); //p
                       a.ap[1] = int.Parse(textBox2.Text); //l
                       a.ap[3] = a.ap[0] * a.ap[1];
                       a.ap[4] = 2 * (a.ap[0] + a.ap[1]);
                       label5.Text = b.jl[0] + a.ap[0] + " x " + a.ap[1] + "\n            = " + a.ap[3].ToString() + "\n" + b.jl[1] + "2 x (" + a.ap[0] + " + " + a.ap[1] + ")\n               = " + a.ap[4];
                       break;
                   case "balok":
                       b.jl[0] = "Luas adalah = 2 x (PL + LT + PT) \n            = ";
                       b.jl[1] = "volume adalah = P x L x T \n              = ";
                       a.ap[0] = int.Parse(textBox1.Text); //p
                       a.ap[1] = int.Parse(textBox2.Text); //l
                       a.ap[2] = int.Parse(textBox3.Text); //t
                       a.ap[3] = 2 * ((a.ap[0] * a.ap[1]) + (a.ap[1] * a.ap[2]) + (a.ap[0] * a.ap[2]));
                       a.ap[4] = a.ap[0] * a.ap[1] * a.ap[2];
                       label5.Text = b.jl[0] + "2 x ((" + a.ap[0] + " x " + a.ap[1] + ") + (" + a.ap[1] + " x " + a.ap[2] + ") + (" + a.ap[0] + " x " + a.ap[2] + "))\n              = " + a.ap[3].ToString() + "\n" + b.jl[1] + "2 x (" + a.ap[0] + " + " + a.ap[1] + ")\n             = " + a.ap[4];
                       break;
                   case "kubus":
                       b.jl[0] = "Luas adalah = 6 x (S x S) \n            = ";
                       b.jl[1] = "volume adalah = S x S x S \n               = ";
                       a.ap[0] = int.Parse(textBox1.Text); //s
                       a.ap[3] = 6*(a.ap[0]*a.ap[0]);
                       a.ap[4] = a.ap[0] * a.ap[0] * a.ap[0];
                       label5.Text = b.jl[0] + "6 x (" + a.ap[0] + " x " + a.ap[0] + ") \n            = " +a.ap[3]+"\n"+ b.jl[1] +a.ap[0]+" x "+a.ap[0]+" x "+a.ap[0] + ")\n               = " + a.ap[4];
                       break;
                   case "tabung":
                       b.jl[0] = "Luas adalah = (2 x Ls)+(Kls x T) \n            = ";
                       b.jl[1] = "volume adalah = 3,14 x R x R x T \n              = ";
                       a.ap[0] = int.Parse(textBox1.Text); //r
                       a.ap[1] = int.Parse(textBox2.Text); //t
                       a.v[0] = 3.14f;
                       a.v[1] = 2 * a.v[0] * a.ap[0];
                       a.v[2] = a.v[0] * a.ap[0] * a.ap[0];
                       a.v[3] = (2*a.v[1])+(a.v[2]*a.ap[1]);
                       a.v[4] = a.v[0] * (a.ap[0] * a.ap[0]) * a.ap[1];
                       label5.Text = b.jl[0] + "(2 x " + a.v[1] + ") + (" + a.v[2] + " x " + a.ap[1] + ")\n            = " + a.v[3] + "\n" + b.jl[1] + "3,14 x (" + a.ap[0].ToString() + " x " + a.ap[0] + " x " + a.ap[1] +")\n              = " + a.v[4];
                       break;
                 /*  case "balok":
                       b.jl[0] = "Luas adalah = 2 x (PL + LT + PT) \n            = ";
                       b.jl[1] = "volume adalah = P x L x T \n             = ";
                       a.ap[0] = int.Parse(textBox1.Text); //p
                       a.ap[1] = int.Parse(textBox2.Text); //l
                       a.ap[2] = int.Parse(textBox3.Text); //t
                       a.ap[3] = 2 * ((a.ap[0] * a.ap[1]) + (a.ap[1] * a.ap[2]) + (a.ap[0] * a.ap[2]));
                       a.ap[4] = a.ap[0] * a.ap[1] * a.ap[2];
                       label5.Text = b.jl[0] + "2 x ((" + a.ap[0] + " x " + a.ap[1] + ") + (" + a.ap[1] + " x " + a.ap[2] + ") + (" + a.ap[0] + " x " + a.ap[2] + "))\n            = " + a.ap[3].ToString() + "\n" + b.jl[1] + "2 x (" + a.ap[0] + " + " + a.ap[1] + ")\n             = " + a.ap[4];
                       break;
                   case "balok":
                       b.jl[0] = "Luas adalah = 2 x (PL + LT + PT) \n            = ";
                       b.jl[1] = "volume adalah = P x L x T \n             = ";
                       a.ap[0] = int.Parse(textBox1.Text); //p
                       a.ap[1] = int.Parse(textBox2.Text); //l
                       a.ap[2] = int.Parse(textBox3.Text); //t
                       a.ap[3] = 2 * ((a.ap[0] * a.ap[1]) + (a.ap[1] * a.ap[2]) + (a.ap[0] * a.ap[2]));
                       a.ap[4] = a.ap[0] * a.ap[1] * a.ap[2];
                       label5.Text = b.jl[0] + "2 x ((" + a.ap[0] + " x " + a.ap[1] + ") + (" + a.ap[1] + " x " + a.ap[2] + ") + (" + a.ap[0] + " x " + a.ap[2] + "))\n            = " + a.ap[3].ToString() + "\n" + b.jl[1] + "2 x (" + a.ap[0] + " + " + a.ap[1] + ")\n             = " + a.ap[4];
                       break; */

                   default:
                       MessageBox.Show("Rumus tidak tersedia");
                       textBox2.Enabled = false;
                       textBox3.Enabled = false;
                       textBox1.Enabled = false;
                       break;
            }
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.ShiftKey)
            {
                textBox2.Focus();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.ShiftKey)
            {
                textBox3.Focus();
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.ShiftKey)
            {
                button1.PerformClick();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://profile.mougyzui.repl.co/");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            label5.Text = "";
        }

    }


    class LV : Rumus
    {
        public override void mms()
        {
            Rumus li = new Rumus();
            li.mms();
            string message = li.jl[3];
            string title = li.jl[4];
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
                while (result == DialogResult.No)
                {
                   result = MessageBox.Show(message, title, buttons);
                }
        }
    }
}
